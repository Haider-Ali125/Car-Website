import "./AboutSec1.css";

const AboutSec1 = () => {
  return (
    <div class="About-sectoin1">
      <h3 class="Aboutsect1-head">About US</h3>

      <div class="last-para">
        <p>
          Get a vehicle for any event and experience a safe.
        </p>
        <p>pleasant trip to your destination.</p>
      </div>
    </div>
  );
};

export default AboutSec1;
