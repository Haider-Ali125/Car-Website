import "./Fleet1.css";

const Fleetssec1 = () => {
  return (
    <div class="Feelt1">
      <h3 class="Feelt1-head">Fleet</h3>

      <div class="Feelt1-sect1-para">
        <p>Get a vehicle for any event and experience a safe.</p>
        <p>pleasant trip to your destination.</p>
      </div>
    </div>
  );
};

export default Fleetssec1;
