import "./ContactSec4.css";

const ContactSec4 = () => {
  return <div class="Contact-section5"></div>;
};

export default ContactSec4;
