import "./contactSect1.css";

const ContactSect1 = () => {
  return (
    <div class="Contact-sectoin1">
      <h3 class="About-head">Contact US</h3>

      <div class="contact-sect1-para">
        <p>Get a vehicle for any event and experience a safe.</p>
        <p>pleasant trip to your destination.</p>
      </div>
    </div>
  );
};

export default ContactSect1;
