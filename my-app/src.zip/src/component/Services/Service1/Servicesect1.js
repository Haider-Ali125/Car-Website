import "./Ser-sect1.css";

const Servicesect1 = () => {
  return (
    <div class="Serv-sectoin1">
      <h3 class="Serv-sectoin1-head">Services</h3>

      <div class="Serv-sectoin1-para">
        <p>Get a vehicle for any event and experience a safe,</p>
        <p>pleasant trip to your destination.</p>
      </div>
    </div>
  );
};

export default Servicesect1;
