import "./Health4.css";

const Health4 = () => {
  return <div class="Health4-sectoin1">
  <h3 class="About-head">Health & Safety</h3>

  <div class="Health4-sect1-para">
    <p>Get a vehicle for any event and experience a safe.</p>
    <p>pleasant trip to your destination.</p>
  </div>
</div>;
};

export default Health4;
